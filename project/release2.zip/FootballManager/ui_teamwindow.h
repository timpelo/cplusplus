/********************************************************************************
** Form generated from reading UI file 'teamwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEAMWINDOW_H
#define UI_TEAMWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TeamWindow
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QListWidget *playerList;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *budgetTotal;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_2;
    QLabel *label_5;
    QDoubleSpinBox *budgetTraining;
    QLabel *label_3;
    QLabel *label_7;
    QLabel *label_6;
    QDoubleSpinBox *budgetStadion;
    QLabel *label_9;
    QLabel *label_4;
    QLabel *label_8;
    QDoubleSpinBox *budgetHealthcare;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *TeamWindow)
    {
        if (TeamWindow->objectName().isEmpty())
            TeamWindow->setObjectName(QStringLiteral("TeamWindow"));
        TeamWindow->resize(860, 860);
        TeamWindow->setMinimumSize(QSize(860, 860));
        TeamWindow->setMaximumSize(QSize(8600, 860));
        TeamWindow->setBaseSize(QSize(860, 860));
        horizontalLayoutWidget = new QWidget(TeamWindow);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(19, 19, 821, 821));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        playerList = new QListWidget(horizontalLayoutWidget);
        playerList->setObjectName(QStringLiteral("playerList"));
        playerList->setMaximumSize(QSize(400, 16777215));

        horizontalLayout->addWidget(playerList);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(horizontalLayoutWidget);
        label->setObjectName(QStringLiteral("label"));
        QFont font;
        font.setPointSize(16);
        font.setItalic(false);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        budgetTotal = new QLabel(horizontalLayoutWidget);
        budgetTotal->setObjectName(QStringLiteral("budgetTotal"));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setWeight(50);
        budgetTotal->setFont(font1);
        budgetTotal->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(budgetTotal);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        label_2 = new QLabel(horizontalLayoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font2;
        font2.setBold(true);
        font2.setWeight(75);
        label_2->setFont(font2);

        verticalLayout->addWidget(label_2);

        label_5 = new QLabel(horizontalLayoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout->addWidget(label_5);

        budgetTraining = new QDoubleSpinBox(horizontalLayoutWidget);
        budgetTraining->setObjectName(QStringLiteral("budgetTraining"));

        verticalLayout->addWidget(budgetTraining);

        label_3 = new QLabel(horizontalLayoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout->addWidget(label_3);

        label_7 = new QLabel(horizontalLayoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setFont(font2);

        verticalLayout->addWidget(label_7);

        label_6 = new QLabel(horizontalLayoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        verticalLayout->addWidget(label_6);

        budgetStadion = new QDoubleSpinBox(horizontalLayoutWidget);
        budgetStadion->setObjectName(QStringLiteral("budgetStadion"));

        verticalLayout->addWidget(budgetStadion);

        label_9 = new QLabel(horizontalLayoutWidget);
        label_9->setObjectName(QStringLiteral("label_9"));

        verticalLayout->addWidget(label_9);

        label_4 = new QLabel(horizontalLayoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setFont(font2);

        verticalLayout->addWidget(label_4);

        label_8 = new QLabel(horizontalLayoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        verticalLayout->addWidget(label_8);

        budgetHealthcare = new QDoubleSpinBox(horizontalLayoutWidget);
        budgetHealthcare->setObjectName(QStringLiteral("budgetHealthcare"));

        verticalLayout->addWidget(budgetHealthcare);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(TeamWindow);

        QMetaObject::connectSlotsByName(TeamWindow);
    } // setupUi

    void retranslateUi(QWidget *TeamWindow)
    {
        TeamWindow->setWindowTitle(QApplication::translate("TeamWindow", "Form", 0));
        label->setText(QApplication::translate("TeamWindow", "Budget", 0));
        budgetTotal->setText(QApplication::translate("TeamWindow", "83,2 mil", 0));
        label_2->setText(QApplication::translate("TeamWindow", "Training", 0));
        label_5->setText(QApplication::translate("TeamWindow", "How much money you want to spend to train your players? This increases your win chances", 0));
        label_3->setText(QString());
        label_7->setText(QApplication::translate("TeamWindow", "Stadion", 0));
        label_6->setText(QApplication::translate("TeamWindow", "How moch money you want to spend to maintain your stadion? This increases your income.", 0));
        label_9->setText(QString());
        label_4->setText(QApplication::translate("TeamWindow", "Healthcare", 0));
        label_8->setText(QApplication::translate("TeamWindow", "How much you want to use to make your players healthier? This lowers the risk of injuries", 0));
    } // retranslateUi

};

namespace Ui {
    class TeamWindow: public Ui_TeamWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TEAMWINDOW_H

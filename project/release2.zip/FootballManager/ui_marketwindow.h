/********************************************************************************
** Form generated from reading UI file 'marketwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MARKETWINDOW_H
#define UI_MARKETWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MarketWindow
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QListView *marketList;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer;
    QPushButton *buyButton;
    QPushButton *sellButton;
    QSpacerItem *verticalSpacer_2;
    QListWidget *teamList;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_5;
    QLabel *label;
    QSpacerItem *horizontalSpacer_3;

    void setupUi(QWidget *MarketWindow)
    {
        if (MarketWindow->objectName().isEmpty())
            MarketWindow->setObjectName(QStringLiteral("MarketWindow"));
        MarketWindow->resize(860, 860);
        MarketWindow->setMinimumSize(QSize(860, 860));
        MarketWindow->setBaseSize(QSize(860, 860));
        horizontalLayoutWidget = new QWidget(MarketWindow);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(19, 59, 821, 781));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        marketList = new QListView(horizontalLayoutWidget);
        marketList->setObjectName(QStringLiteral("marketList"));

        horizontalLayout->addWidget(marketList);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        buyButton = new QPushButton(horizontalLayoutWidget);
        buyButton->setObjectName(QStringLiteral("buyButton"));

        verticalLayout->addWidget(buyButton);

        sellButton = new QPushButton(horizontalLayoutWidget);
        sellButton->setObjectName(QStringLiteral("sellButton"));

        verticalLayout->addWidget(sellButton);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);


        horizontalLayout->addLayout(verticalLayout);

        teamList = new QListWidget(horizontalLayoutWidget);
        teamList->setObjectName(QStringLiteral("teamList"));

        horizontalLayout->addWidget(teamList);

        horizontalLayoutWidget_2 = new QWidget(MarketWindow);
        horizontalLayoutWidget_2->setObjectName(QStringLiteral("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(19, 10, 821, 51));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        label_2 = new QLabel(horizontalLayoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font;
        font.setPointSize(16);
        label_2->setFont(font);

        horizontalLayout_2->addWidget(label_2);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        horizontalSpacer = new QSpacerItem(50, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_5);

        label = new QLabel(horizontalLayoutWidget_2);
        label->setObjectName(QStringLiteral("label"));
        label->setFont(font);

        horizontalLayout_2->addWidget(label);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);


        retranslateUi(MarketWindow);

        QMetaObject::connectSlotsByName(MarketWindow);
    } // setupUi

    void retranslateUi(QWidget *MarketWindow)
    {
        MarketWindow->setWindowTitle(QApplication::translate("MarketWindow", "Form", 0));
        buyButton->setText(QApplication::translate("MarketWindow", "Buy", 0));
        sellButton->setText(QApplication::translate("MarketWindow", "Sell", 0));
        label_2->setText(QApplication::translate("MarketWindow", "Market", 0));
        label->setText(QApplication::translate("MarketWindow", "Your Team", 0));
    } // retranslateUi

};

namespace Ui {
    class MarketWindow: public Ui_MarketWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MARKETWINDOW_H

/********************************************************************************
** Form generated from reading UI file 'match.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MATCH_H
#define UI_MATCH_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Match
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_5;
    QLabel *teamLabel;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_4;
    QLCDNumber *homeGoalDisplay;
    QSpacerItem *horizontalSpacer;
    QLCDNumber *guestGoalDisplay;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *Match)
    {
        if (Match->objectName().isEmpty())
            Match->setObjectName(QStringLiteral("Match"));
        Match->resize(860, 860);
        Match->setMinimumSize(QSize(860, 860));
        Match->setMaximumSize(QSize(860, 16777215));
        Match->setBaseSize(QSize(860, 860));
        verticalLayoutWidget = new QWidget(Match);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(60, 20, 731, 521));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);

        teamLabel = new QLabel(verticalLayoutWidget);
        teamLabel->setObjectName(QStringLiteral("teamLabel"));
        QFont font;
        font.setPointSize(20);
        teamLabel->setFont(font);

        horizontalLayout_3->addWidget(teamLabel);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);

        homeGoalDisplay = new QLCDNumber(verticalLayoutWidget);
        homeGoalDisplay->setObjectName(QStringLiteral("homeGoalDisplay"));
        QFont font1;
        font1.setBold(false);
        font1.setWeight(50);
        homeGoalDisplay->setFont(font1);

        horizontalLayout->addWidget(homeGoalDisplay);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        guestGoalDisplay = new QLCDNumber(verticalLayoutWidget);
        guestGoalDisplay->setObjectName(QStringLiteral("guestGoalDisplay"));
        QFont font2;
        font2.setFamily(QStringLiteral("Calibri"));
        guestGoalDisplay->setFont(font2);
        guestGoalDisplay->setSmallDecimalPoint(false);

        horizontalLayout->addWidget(guestGoalDisplay);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        retranslateUi(Match);

        QMetaObject::connectSlotsByName(Match);
    } // setupUi

    void retranslateUi(QWidget *Match)
    {
        Match->setWindowTitle(QApplication::translate("Match", "Form", 0));
        teamLabel->setText(QApplication::translate("Match", "teams", 0));
    } // retranslateUi

};

namespace Ui {
    class Match: public Ui_Match {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MATCH_H
